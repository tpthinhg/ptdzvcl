<?php require_once('include/head.php'); ?>
<title>Trang Chủ</title>
<?php require_once('include/nav.php'); 
$don = mysqli_fetch_assoc(mysqli_query($ketnoi, "SELECT COUNT(*) FROM `ticket` WHERE `status` = 'scam' ")) ['COUNT(*)'];
?>
<div id="main" class="main">
    
    <div class="section-gap section-intro">
        <div class="container">
            <div class="row">
                <div class="col-12">
        <div class="section-heading">
            <div class="title">
                KIỂM TRA &amp; TỐ CÁO SCAMMER
            </div>
            <div class="line"></div>
            <div class="desc">
                <p>Check&nbsp;<strong>"SĐT, STK Ngân Hàng..."</strong>&nbsp;trước khi giao dịch, bằng cách nhập vào&nbsp;<strong>"ô Tìm Kiếm"</strong>.<br />
Với hơn&nbsp;<strong>18.000 dữ liệu Scam trên MXH &amp; hàng trăm đơn tố cáo gửi lên mỗi ngày</strong>, sẽ giúp bạn mua bán an toàn hơn khi online !!!</p>
            </div>
        </div>
    </div>
    <div class="col-12">
        <div class="row align-items-center">
            <div class="col-lg-6">
                <form action="" method="POST">
                    <input type="hidden" name="_token" value="4b5uVWuaPU7AnnZeMWN2roMiuqkI0RK1oamv4IVX">                    <div class="form-group position-relative">
                        <input type="text" class="form-control" name="search"
                               placeholder="Nhập số điện thoại, số tài khoản ngân hàng ...">
                        <button type="submit">
                            <i class="far fa-search"></i>
                        </button>
                    </div>
                    <a href="/service/denounce" class="btn-theme btn-theme_primary">
                        Gửi Tố Cáo Scam
                        <span></span>
                    </a>
                    <a href="service/reputation" class="btn-theme btn-theme_success">
                        Check Quỹ Bảo Hiểm
                        <span></span>
                    </a>
                </form>
            </div>
            <div class="col-lg-6">
                <div class="intro-image">
                    <img src="img-pqn/bg-scam.png" class="w-100 img-fluid h-auto" alt="">
                </div>
            </div>
        </div>
    </div>




                <div class="col-12">
                    <div class="section-heading">
                    <div class="title">
                            <?=$don;?> SCAM BỊ TỐ CÁO: <?=date('d/m/Y');?>
                          </div>
                        </div>
                    <div class="scam-list">
<?php
$i=1;
$result = mysqli_query($ketnoi,"SELECT * FROM `ticket` WHERE `status` = 'scam' ORDER BY id desc limit 0, 10");
while($row = mysqli_fetch_assoc($result)) { ?>
                                                                            <div class="scam-item d-flex align-items-center py-3 px-4 border bg-white">
                            <div class="scam-title">
                                <span class="scam-title_icon">
                                    <i class="fas fa-user"></i>
                                </span>
                                <a href="/scamer/<?=$row['anh'];?>" class="scam-title_link">
                                    <?=$i++;?>. <?=$row['username'];?>
                                </a>
                            </div>
                            <div class="scam-info ml-auto">
                                <span class="scam-info_time">
                                    <i class="fas fa-clock"></i>
                                    <?=$row['ngay'];?>
                                </span>
                                <span class="scam-info_phone">
                                    <i class="fas fa-money-bill-alt"></i>
                                          MB :  ...
                                </span>
                                <span class="scam-info_eye">
                                    <i class="fas fa-eye"></i>
                                    303 lượt xem
                                </span>
                            </div>
                        </div>
                        <?php } ?>
                                                    
                                                                        </div>
                </div>
            </div>
        </div>
    </div>
        <div class="section-gap section-service">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section-heading">
                        <div class="title">
                            Dịch Vụ Nổi Bật
                        </div>
                        <div class="line"></div>
                        <div class="desc">
                            Các tin tức nổi bật về tình trạng scam hiện nay. Hãy đọc tin tức để phòng hờ các kẻ xấu lợi
                            dụng scam
                        </div>
                    </div>
                </div>
                <div class="col-12">
                    <div class="row row-col-10">
                                                <div class="col-12 col-sm-6 col-lg-3">
                            <div class="service-card">
                                <div class="service-bg_main"></div>
                                <div class="service-bg_before"></div>
                                <div class="service-bg_after"></div>
                                <div class="service-icon">
                                    <i class="fas fa-check"></i>
                                </div>
                                <div class="service-content">
                                    <a href="/" class="service-content_title">
                                        Check scammer
                                    </a>
                                    <div class="service-content_desc">
                                        Bạn chỉ cần nhập SDT, STK ngân hàng, thông tin của scammer vào trong ô tìm kiếm sẽ được phơi bày
                                    </div>
                                </div>
                                <div class="service-action">
                                    <a href="/" class="btn-theme btn-theme_white">
                                        Truy Cập
                                        <span></span>
                                    </a>
                                </div>
                            </div>
                        </div>
                                                    <div class="col-12 col-sm-6 col-lg-3">
                            <div class="service-card">
                                <div class="service-bg_main"></div>
                                <div class="service-bg_before"></div>
                                <div class="service-bg_after"></div>
                                <div class="service-icon">
                                    <i class="fas fa-check"></i>
                                </div>
                                <div class="service-content">
                                    <a href="service/denounce" class="service-content_title">
                                        Tố cáo lừa đảo
                                    </a>
                                    <div class="service-content_desc">
                                        Bạn muốn tố cáo một ai đó đang lừa đảo bạn ,đã đủ chứng cứ để kẻ lừa đảo phải chịu hình phạt
                                    </div>
                                </div>
                                <div class="service-action">
                                    <a href="/service/denounce" class="btn-theme btn-theme_white">
                                        Tố cáo
                                        <span></span>
                                    </a>
                                </div>
                            </div>
                        </div>
                                                    <div class="col-12 col-sm-6 col-lg-3">
                            <div class="service-card">
                                <div class="service-bg_main"></div>
                                <div class="service-bg_before"></div>
                                <div class="service-bg_after"></div>
                                <div class="service-icon">
                                    <i class="fas fa-check"></i>
                                </div>
                                <div class="service-content">
                                    <a href="/service/reputation" class="service-content_title">
                                        Check quỹ bảo hiểm
                                    </a>
                                    <div class="service-content_desc">
                                        Check quỹ bảo hiểm được Admin VietNam đảm bảo xác nhận uy tín trên từng giao dịch
                                    </div>
                                </div>
                                <div class="service-action">
                                    <a href="service/reputation" class="btn-theme btn-theme_white">
                                        Check quỹ
                                        <span></span>
                                    </a>
                                </div>
                            </div>
                        </div>
                                                    <div class="col-12 col-sm-6 col-lg-3">
                            <div class="service-card">
                                <div class="service-bg_main"></div>
                                <div class="service-bg_before"></div>
                                <div class="service-bg_after"></div>
                                <div class="service-icon">
                                    <i class="fas fa-check"></i>
                                </div>
                                <div class="service-content">
                                    <a href="https://TRUMTHE1S.VN" class="service-content_title">
                                        TRUMTHE1S.VN
                                    </a>
                                    <div class="service-content_desc">
                                        ĐỔI THẺ CÀO UY TÍN TỰ ĐÔNG GIAO DỊCH NHANH CHÓNG
                                    </div>
                                </div>
                                <div class="service-action">
                                    <a href="https://TRUMTHE1S.VN" class="btn-theme btn-theme_white">
                                        Truy Cập
                                        <span></span>
                                    </a>
                                </div>
                            </div>
                        </div>
                                                </div>
                </div>
            </div>
        </div>
    </div>
                <div class="section-gap section-article">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="section-heading">
                            <div class="title">
                                Tin tức nổi bật
                            </div>
                            <div class="line"></div>
                            <div class="desc">
                                Các tin tức nổi bật về tình trạng scam hiện nay. Hãy đọc tin tức để phòng hờ các kẻ xấu lợi dụng scam
                            </div>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="row row-col-10">
                                                        <div class="col-12 col-sm-6 col-lg-3">
                                <a href="https://TRUMTHE1S.VN" class="article-card card">
                                    <div class="card-header">
                                        <img src="img-pqn/bg-scam.png"
                                             class="mw-100 image-cover transition-default">
                                    </div>
                                    <div class="card-body py-0 d-flex flex-column">
                                        <div class="card-meta">
                                            Ngày đăng:&nbsp;09-05-2022
                                        </div>
                                        <div class="card-title">
                                            Đổi thẻ cào thành tiền mặt
                                        </div>
                                        <div class="card-text">
                                            
                                        </div>
                                        <div class="card-link mt-auto">
                                            Xem chi tiết <i class="far fa-long-arrow-alt-right"></i>
                                        </div>
                                    </div>
                                </a>
                            </div>
                                                            <div class="col-12 col-sm-6 col-lg-3">
                                <a href="https://www.facebook.com/dvptrunggianmmo" class="article-card card">
                                    <div class="card-header">
                                        <img src="img-pqn/bg-scam.png"
                                             class="mw-100 image-cover transition-default">
                                    </div>
                                    <div class="card-body py-0 d-flex flex-column">
                                        <div class="card-meta">
                                            Ngày đăng:&nbsp;14-03-2022
                                        </div>
                                        <div class="card-title">
                                            Supper Team Admin VietNam 
                                        </div>
                                        <div class="card-text">
                                            Super Team Admin
                                        </div>
                                        <div class="card-link mt-auto">
                                            Xem chi tiết <i class="far fa-long-arrow-alt-right"></i>
                                        </div>
                                    </div>
                                </a>
                            </div>
                                                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="global-modal" class="modal fade" role="dialog">
            <div class="modal-dialog">

                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title">Thông báo</h4>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>

                    </div>
                    <div class="modal-body">
                        <p><p>Mọi chi tiết Nhận Cọc Quỹ Bảo Hiểm TranhLuaDao.INFO Liên Hệ Zalo:0375227405 và chuẩn bị giấy tờ tùy thân ! Trân Trọng</p></p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Đóng</button>
                    </div>
                </div>

            </div>
        </div>
    <?php require_once('include/foot.php'); ?>
<?php require_once('../include/head.php'); ?>
<title>Tố cáo lừa đảo</title>
<?php require_once('../include/nav.php'); ?>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<div id="main" class="main">
    
    
        <div class="section-gap section-report">
        <form method="post" class="form-theme" enctype="multipart/form-data">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-12">
                        <div class="section-heading">
                            <div class="title">
                                THÔNG TIN KẺ LỪA ĐẢO
                            </div>
                            <div class="line"></div>
                        </div>
                    </div>
                    <div class="col-md-10 col-lg-8">
                        <div class="row row-col-10">
                            <div class="col-md-6 col-12">
                                <div class="form-theme_item">
                                    <input type="text" value="" class="form-theme_item__input"
                                           name="hoten">
                                    <label class="form-theme_item__label" for="">
                                        Họ và tên
                                    </label>
                                </div>
                            </div>
                            <div class="col-md-6 col-12">
                                <div class="form-theme_item">
                                    <input type="text" value="" class="form-theme_item__input"
                                           name="sdt">
                                    <label class="form-theme_item__label" for="">
                                        Số điện thoại
                                    </label>
                                </div>
                            </div>
                            <div class="col-md-6 col-12">
                                <div class="form-theme_item">
                                    <input type="text" value="" class="form-theme_item__input" name="stk">
                                    <label class="form-theme_item__label" for="">
                                        Số tài khoản <span class="font-weight-bold text-danger">*</span>
                                    </label>
                                </div>
                            </div>
                            <div class="col-md-6 col-12">
                                <div class="form-theme_item">
                                    <input type="text" value="" class="form-theme_item__input" name="nganhang">
                                    <label class="form-theme_item__label" for="">
                                        Ngân hàng <span class="font-weight-bold text-danger">*</span>
                                    </label>
                                </div>
                            </div>
                            <div class="col-md-6 col-12">
                                <div class="form-theme_item">
                                    <input type="text" value="" class="form-theme_item__input" name="linkfb">
                                    <label class="form-theme_item__label" for="">
                                        ID Facebook Kẻ Lừa Đảo <span class="font-weight-bold text-danger"></span>
                                    </label>
                                </div>
                            </div>
                            <div class="col-md-6 col-12">
                                <div class="form-theme_item">
                                    <input type="file" name="file[]" multiple class="form-theme_item__input" />
                                    <label class="form-theme_item__label" for="">
                                        Hình Ảnh Bằng Chứng Lừa Đảo <span class="font-weight-bold text-danger">*</span>
                                    </label>
                                </div>
                            </div>
                            
                            <div class="col-12 py-0">
                                <div class="form-theme_item">
                                    <div class="form-theme_item__desc px-1 text-muted">
                                        LƯU Ý: Chờ khoảng 15s để Upload ảnh lên sever, bài tố cáo sẽ bị gỡ nếu không
                                        đủ
                                        bằng chứng thuyết phục,
                                    </div>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-theme_item">
                                     <textarea class="form-theme_item__input"
                                               name="lydo" rows="4"></textarea>
                                    <label class="form-theme_item__label" for="">
                                        Nội dung tố cáo <span class="font-weight-bold text-danger">*</span>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-line"></div>
                    <div class="col-12">
                        <div class="section-heading">
                            <div class="title">
                                THÔNG TIN NGƯỜI PHỐT
                            </div>
                            <div class="line"></div>
                        </div>
                    </div>
                    <div class="col-md-10 col-lg-8">
                        <div class="row row-col-10">
                            <div class="col-md-6 col-12 py-md-0">
                                <div class="form-theme_item">
                                    <input type="text" value="" class="form-theme_item__input"
                                           name="hotennp">
                                    <label class="form-theme_item__label" for="">
                                        Họ & tên <span class="font-weight-bold text-danger">*</span>
                                    </label>
                                </div>
                            </div>
                            <div class="col-md-6 col-12 py-md-0">
                                <div class="form-theme_item">
                                    <input type="text" value=""
                                           class="form-theme_item__input" name="sdtnp">
                                    <label class="form-theme_item__label" for="">
                                        Liên hệ zalo
                                    </label>
                                    <div class="form-theme_item__desc p-1 pb-0 text-muted">
                                        Đơn tố cáo sẽ bị gỡ nếu zalo ảo.
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 mt-4">
                                <div class="form-theme_item text-center">
                                    <button type="submit" name="submit" class="btn-theme btn-theme_primary">
                                        GỬI DUYỆT
                                        <span></span>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<?php
date_default_timezone_set("Asia/Ho_Chi_minh");
 $time = date("h:i:s");
 $site = $_SERVER['SERVER_NAME'];
if (isset($_POST["submit"])) {
$name = array();
$tmp_name = array();
$error = array();
$ext = array();
$size = array();

foreach ($_FILES['file']['name'] as $file) {
$name[] = $file;
}
foreach ($_FILES['file']['tmp_name'] as $file){
$tmp_name[] = $file;
}

for ($i=0;$i<count($name);$i++){
if ($error[$i] > 0){
echo $error[$i];
} else{
$number_random = random('1234567890', 4);
 $hoten = $_POST['hoten'];
  $sdt = $_POST['sdt'];
  $nganhang = $_POST['nganhang'];
  $stk = $_POST['stk'];
  $id_fb = $_POST['linkfb'];
  $lydo = $_POST['lydo'];
  $nguoi_phot = $_POST['hotennp'];
  $sdt_nguoip = $_POST['sdtnp'];
$ngay = date('d-m-Y');
$link_phot_mxh = $_POST['link_phot_mxh'];
$random = random('1234567890', 1);
$code = xoadau($hoten);

$temp = preg_split('/[\/\\\\]+/', $name[$i]);
$filename = $temp[count($temp)-1];
$upload_dir = "../anh/";
$upload_file = $upload_dir . "BC_".$number_random.".png";
if (file_exists($upload_file)){ ?>
<script>
Swal.fire("Lỗi", "Ảnh này đã tồn tại trong hệ thống", "error");
</script>
<?php echo '<meta http-equiv="refresh" content="5;url=">';
}
if (move_uploaded_file($tmp_name[$i], $upload_file) ) {
$duong_lik = "/anh/BC_".$number_random.".png";
$getanh = explode(PHP_EOL,$duong_lik);
$countupdate = 0;

foreach($getanh as $row) {
$ketnoi->query("INSERT INTO `anh_bang_chung` SET 
`code` = '$code',
`anh` = '$row' ");
$countupdate++;
}

}
}
}

$create = $ketnoi->query("INSERT INTO `ticket` SET 
    `username` = '".$hoten."',
    `code` = '".$code."',
    `ly_do` = '".$lydo."',
    `status` = 'xuly',
    `sdt` = '".$sdt."',
    `id_fb` = '".$id_fb."',
    `ngan_hang` = '".$nganhang."',
    `anh` = '$code',
    `stk` = '".$stk."',
    `hoten_np` = '".$nguoi_phot."',
    `sdt_np` = '".$sdt_nguoip."',
    `ngay` = '".$ngay."' ");  
 
$curl = curl_init();
curl_setopt_array($curl, array(
  CURLOPT_URL => "https://api.telegram.org/bot5261973073:AAHSp42HYUo7UU73knB_jFsgLsb5kYqhkz8/sendMessage?chat_id=1996812631&text=Có%20đơn%20duyệt%20tại%20$site%20$hoten%20scam%20lúc%20$time",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
));
$response = curl_exec($curl);
curl_close($curl);    
    
   ?>
<script>
Swal.fire("Thành Công", "Chúng tôi sẽ xem xét đơn của bạn", "success");
</script>
<?php
echo '<meta http-equiv="refresh" content="5;url=">'; 
}
?>
<?php require_once('../include/foot.php'); ?>
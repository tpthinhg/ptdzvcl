<?php require_once('../include/head.php'); ?>
<title>Dịch vụ uy tín</title>
<?php require_once('../include/nav.php'); ?>
<div id="main" class="main">
    
    
        <div class="section-gap section-shield">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section-heading">
                        <div class="title">
                            QUỸ BẢO HIỂM MMO
                        </div>
                        <div class="line"></div>
                        <div class="tab">
                            <div class="subtitle">
                                Ấn vào "Tab dịch vụ" để lọc admin !!!
                            </div>
                            <ul class="nav nav-tabs tab-theme">
                                <li class="nav-item">
                                    <a class="nav-link" href="#"
                                       role="tab">
                                        Tất cả
                                    </a>
                                </li>
                                                                    
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-12">
                    <div class="tab-content">
                        <div class="tab-pane fade active show" id="tab-1">
                            <?php
$neww = mysqli_query($ketnoi,"SELECT * FROM `category` ORDER BY id asc");

while($lmg = mysqli_fetch_assoc($neww))
{
?>
                                                                                                <div class="shield-inner">
                                        <div class="shield-list">

                                            <div class="shield-title">
                                                <i class="fas fa-star"></i>
                                                <?=$lmg['code'];?>:
                                                <i class="fas fa-star"></i>
                                            </div>
                                            <?php
$result = mysqli_query($ketnoi,"SELECT * FROM `cards` ORDER BY id desc");

while($check = mysqli_fetch_assoc($result))
{
    if($check['dich_vu'] == $lmg['code']) {
?>                                                                                                    <div class="shield-item">
                                                        <a href="/profile/<?=$check['code'];?>" class="shield-item_link">
                                                            <img src="https://graph.facebook.com/<?=$check['id_fb'];?>/picture?width=100&height=100&access_token=6628568379|c1e620fa708a1d5696fb991c1bde5662" alt="">
                                                            <?=$check['username']?>
                                                        </a>
                                                    </div>
                                            <?php  } }?>                                                
                                        </div>
                                    </div>
                                    <?php } ?>
                                                                    
                                                                                    </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require_once('../include/foot.php'); ?>
<?php require_once('../include/head.php'); ?>
<title>Trang Chủ</title>
<?php require_once('../include/nav.php'); ?>
<?php
if (isset($_GET['code'])) {
$id = $_GET['code'];
}
?>
<?php
$result = mysqli_query($ketnoi,"SELECT * FROM `ticket` WHERE `code` = ".$id."  AND `status` = 'scam' ");
while($row = mysqli_fetch_assoc($result))
{
?>

<div id="main" class="main">
        <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="section-breadcrumb">
                    <ol class="breadcrumb">
                                                <li class="breadcrumb-item">
                            <a href="/">Trang chủ</a>
                        </li>
                                                <li class="breadcrumb-item">
                            <a href="#">Lừa đảo</a>
                        </li>
                                                <li class="breadcrumb-item">
                            <a href="#">Tô Trường Giang</a>
                        </li>
                                            </ol>
                </div>
            </div>
        </div>
    </div>

    
        <div class="section-gap section-scammer">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-12 col-lg-10">
                    <div class="scammer-box">
                        <div class="scammer-box_title">
                            <i class="fas fa-exclamation"></i>
                            Cảnh báo lừa đảo
                        </div>
                        <div class="scammer-box_wrap">
                            <div class="scammer-item">
                                <div class="scammer-item_icon">
                                    <i class="fas fa-user-alt"></i>
                                    Họ và tên:
                                </div>
                                <div class="scammer-item_content">
                                    Tô Trường Giang
                                </div>
                            </div>
                            <div class="scammer-item">
                                <div class="scammer-item_icon">
                                    <i class="fas fa-phone-alt"></i>
                                    Số điện thoại:
                                </div>
                                <div class="scammer-item_content">
                                    0334940776
                                    <a href="javascript:void(0)" class="copy-text" data-text="0334940776">
                                        <i class="fas fa-copy"></i>
                                    </a>
                                </div>
                            </div>
                            <div class="scammer-item">
                                <div class="scammer-item_icon">
                                    <i class="fas fa-credit-card"></i>
                                    Số tài khoản
                                </div>
                                <div class="scammer-item_content">
                                    0334940776
                                    <a href="javascript:void(0)" class="copy-text" data-text="0334940776">
                                        <i class="fas fa-copy"></i>
                                    </a>
                                </div>
                            </div>
                            <div class="scammer-item">
                                <div class="scammer-item_icon">
                                    <i class="fas fa-university"></i>
                                    Ngân hàng
                                </div>
                                <div class="scammer-item_content">
                                    0800002592006
                                </div>
                            </div>
                            <div class="scammer-item flex-wrap flex-md-nowrap">
                                <div class="scammer-item_icon">
                                    <i class="fas fa-images"></i>
                                    Ảnh chụp bằng chứng
                                </div>
                                <div class="scammer-item_content">
                                    <div class="scammer-item_content__image">
                                                                                                                                    <div class="scammer-item_content__image-item">
                                                    <a href="https://admin.vn/storage/scams//8aaeae49-7203-4ca1-823a-50b44a02a1c4-6278e78cd8d70.jpeg" data-fancybox="image-scammer">
                                                        <img src="https://admin.vn/storage/scams//8aaeae49-7203-4ca1-823a-50b44a02a1c4-6278e78cd8d70.jpeg" alt="">
                                                    </a>
                                                </div>
                                                                                            <div class="scammer-item_content__image-item">
                                                    <a href="https://admin.vn/storage/scams//4e3d63a0-1e56-4205-bf7c-b30db33494f1-6278e78cf29c2.jpeg" data-fancybox="image-scammer">
                                                        <img src="https://admin.vn/storage/scams//4e3d63a0-1e56-4205-bf7c-b30db33494f1-6278e78cf29c2.jpeg" alt="">
                                                    </a>
                                                </div>
                                                                                                                        </div>
                                </div>
                            </div>
                            <div class="scammer-item flex-wrap flex-md-nowrap">
                                <div class="scammer-item_icon">
                                    <i class="fas fa-pen-square"></i>
                                    Mô tả hình thức
                                </div>
                                <div class="scammer-item_content">
                                    Scam
                                    <br>
                                    <b>Nguồn tố cáo</b>
                                    <a href="https://admin.vn/scams/to-truong-giang-286.html">
                                        https://admin.vn/scams/to-truong-giang-286.html
                                    </a>
                                    <a href="javascript:void(0)" class="copy-text"
                                       data-text="https://admin.vn/scams/to-truong-giang-286.html">
                                        <i class="fas fa-copy"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="scammer-box">
                        <div class="scammer-box_title">
                            <i class="fas fa-user-alt"></i>
                            Người tố cáo
                        </div>
                        <div class="scammer-box_wrap">
                            <div class="scammer-item">
                                <div class="scammer-item_icon">
                                    <i class="fas fa-user-alt"></i>
                                    Họ và tên:
                                </div>
                                <div class="scammer-item_content">
                                    Dương ******* ******
                                </div>
                            </div>
                            <div class="scammer-item">
                                <div class="scammer-item_icon">
                                    <i class="fas fa-phone-alt"></i>
                                    Liên hệ:
                                </div>
                                <div class="scammer-item_content">
                                    093478****
                                </div>
                            </div>
                            <div class="scammer-item">
                                <div class="scammer-item_icon">
                                    <i class="fas fa-link"></i>
                                    Link phốt MXH
                                </div>
                                <div class="scammer-item_content">
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                                            <div class="scammer-box">
                            <div class="scammer-box_title">
                                <i class="fas fa-list-alt"></i>
                                Danh sách scammer
                            </div>
                            <div class="scammer-box_wrap">
                                <div class="scam-list">

                                                                            <div class="scam-item d-flex align-items-center py-3 px-4 border bg-white">
                                            <div class="scam-title">
                                        <span class="scam-title_icon">
                                            <i class="fas fa-user"></i>
                                        </span>
                                                <a href="https://admin.vn/scams/huy-chinh-chan-285.html"
                                                   class="scam-title_link">
                                                    Huy chinh chấn
                                                </a>
                                            </div>
                                            <div class="scam-info ml-auto">
                                        <span class="scam-info_time">
                                            <i class="fas fa-clock"></i>
                                            09-05-2022
                                        </span>
                                                <span class="scam-info_phone">
                                           <i class="fas fa-money-bill-alt"></i>
                                          Mb bank :  0250520079999
                                        </span>
                                                <span class="scam-info_eye">
                                            <i class="fas fa-eye"></i>
                                            44 lượt xem
                                        </span>
                                            </div>
                                        </div>
                                                                            <div class="scam-item d-flex align-items-center py-3 px-4 border bg-white">
                                            <div class="scam-title">
                                        <span class="scam-title_icon">
                                            <i class="fas fa-user"></i>
                                        </span>
                                                <a href="https://admin.vn/scams/hoang-a-su-2.html"
                                                   class="scam-title_link">
                                                    Hoàng A Sù
                                                </a>
                                            </div>
                                            <div class="scam-info ml-auto">
                                        <span class="scam-info_time">
                                            <i class="fas fa-clock"></i>
                                            05-05-2022
                                        </span>
                                                <span class="scam-info_phone">
                                           <i class="fas fa-money-bill-alt"></i>
                                          MB :  33333366666
                                        </span>
                                                <span class="scam-info_eye">
                                            <i class="fas fa-eye"></i>
                                            226 lượt xem
                                        </span>
                                            </div>
                                        </div>
                                                                            <div class="scam-item d-flex align-items-center py-3 px-4 border bg-white">
                                            <div class="scam-title">
                                        <span class="scam-title_icon">
                                            <i class="fas fa-user"></i>
                                        </span>
                                                <a href="https://admin.vn/scams/hoang-van-a-1.html"
                                                   class="scam-title_link">
                                                    Hoang Van A
                                                </a>
                                            </div>
                                            <div class="scam-info ml-auto">
                                        <span class="scam-info_time">
                                            <i class="fas fa-clock"></i>
                                            26-04-2022
                                        </span>
                                                <span class="scam-info_phone">
                                           <i class="fas fa-money-bill-alt"></i>
                                          VCB :  36633663
                                        </span>
                                                <span class="scam-info_eye">
                                            <i class="fas fa-eye"></i>
                                            140 lượt xem
                                        </span>
                                            </div>
                                        </div>
                                    
                                </div>
                            </div>
                        </div>
                                    </div>
            </div>
        </div>
    </div>
    <?php require_once('../include/foot.php'); ?>
    <?php } ?>
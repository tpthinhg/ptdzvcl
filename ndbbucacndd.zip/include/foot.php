<footer class="footer">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="footer-top">
                    <div class="row">
                        <div class="col-md-6 col-lg-3">
                            <div class="footer-item">
                                <div class="footer-item_text">
                                    DATA CENTER ADMIN VIETNAM
                                </div>
                                <div class="footer-item_link">
                                    Hotline:
                                    <a href="tel:"></a>
                                </div>
                                <div class="footer-item_link">
                                    Điện thoại:
                                    <a href="tel:1900 5121">1900 5121</a>
                                </div>
                                <div class="footer-item_link">
                                    Email:
                                    <a href="mailto:example@gmail.com">admin.vn@admin.com</a>
                                </div>
                                <div class="footer-item_link">
                                    Địa chỉ: Hà Tĩnh
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-3 col-6">
            <div class="footer-item">
                <div class="footer-item_text footer-item_decor">
                    Dịch vụ Center
                </div>
                                    <ul class="footer-item_list">
                                                    <li>
                                <a href="https://trumthe1s.vn">Đổi thẻ cào</a>
                            </li>
                                                    <li>
                                <a href="https://pqnit.asia/">PQNIT.ASIA</a>
                            </li>
                                                    <li>
                                <a href="service/rules">Đăng kí quỹ bảo hiểm Admin VN</a>
                            </li>
                                            </ul>
                            </div>
        </div>
            <div class="col-md-6 col-lg-3 col-6">
            <div class="footer-item">
                <div class="footer-item_text footer-item_decor">
                    Thông tin Admin
                </div>
                                    <ul class="footer-item_list">
                                                    <li>
                                <a href="news">Tin tức</a>
                            </li>
                                                    <li>
                                <a href="/">Supper Team Free Fire</a>
                            </li>
                                                    <li>
                                <a href="/">Supper Team MMO</a>
                            </li>
                                            </ul>
                            </div>
        </div>
    

                        <div class="col-md-6 col-lg-3 col-6">
                            <div class="footer-item">
                                <div class="footer-item_text footer-item_decor">
                                    Cộng đồng
                                </div>
                                <ul class="list-unstyled mb-0 footer-item_social">
                                    <li class="facebook">
                                        <a href="https://www.facebook.com/dvptrunggianmmo">
                                            <i class="fab fa-facebook-f"></i>
                                        </a>
                                    </li>
                                    <li class="telegram">
                                        <a href="@trumgd">
                                            <i class="fab fa-telegram-plane"></i>
                                        </a>
                                    </li>
                                    <li class="twitter">
                                        <a href="https://www.facebook.com/dvptrunggianmmo">
                                            <i class="fab fa-twitter"></i>
                                        </a>
                                    </li>
                                    <li class="youtube">
                                        <a href="https://www.facebook.com/dvptrunggianmmo">
                                            <i class="fab fa-youtube"></i>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>

<div class="float-buttons">
    <a href="/service/denounce" class="btn-theme btn-theme_primary">TỐ CÁO <span></span></a>
    <a href="/service/reputation" class="btn-theme btn-theme_success">CHECK UY TÍN<span></span></a>
</div>

<!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=U321312323"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());

        gtag('config', 'U321312323');
    </script>
    

<script type=" text/javascript" src="/assets/default/plugins/jquery.min.js"></script>
<script type="text/javascript" src="/assets/default/plugins/bootstrap/bootstrap.bundle.min.js"></script>
<script type="text/javascript" src="/assets/default/plugins/swiper/swiper-bundle.min.js"></script>
<script type="text/javascript" src="/assets/default/plugins/select2/js/select2.min.js"></script>
<script type="text/javascript" src="/assets/default/plugins/fancybox/fancybox.min.js"></script>
<script type="text/javascript" src="/assets/default/js/app.js"></script>

<script src='https://www.google.com/recaptcha/api.js?render=&onload=onloadCallback&render=explicit'></script>
<script>
    function onloadCallback() {
        grecaptcha.ready(function() {
            grecaptcha.execute('', {
                action: 'homepage'
            }).then(function (token) {
                $(".recaptcha_token").val(token);

            });
        });
    }
</script>


            <script>
            $(document).ready(function () {
                $('#global-modal').modal('show');
            });
        </script>
    

</body>

</html>
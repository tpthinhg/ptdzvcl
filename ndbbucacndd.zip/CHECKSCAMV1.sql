-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Máy chủ: localhost:3306
-- Thời gian đã tạo: Th5 17, 2022 lúc 07:08 PM
-- Phiên bản máy phục vụ: 10.5.15-MariaDB-cll-lve
-- Phiên bản PHP: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `sunmomos_sub27`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `abc`
--

CREATE TABLE `abc` (
  `id` int(11) NOT NULL,
  `code` varchar(32) DEFAULT NULL,
  `username` text CHARACTER SET utf8mb4 NOT NULL,
  `sdt` text DEFAULT NULL,
  `id_fb` text CHARACTER SET utf8mb4 DEFAULT NULL,
  `website` text CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci NOT NULL,
  `dich_vu` text CHARACTER SET utf8mb4 DEFAULT NULL,
  `mo_ta` text CHARACTER SET utf8mb4 DEFAULT NULL,
  `money` text CHARACTER SET utf8mb4 DEFAULT NULL,
  `gmail` text CHARACTER SET utf8mb4 DEFAULT NULL,
  `ngan_hang` text CHARACTER SET utf8mb4 DEFAULT NULL,
  `vi_momo` text CHARACTER SET utf8mb4 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `taikhoan` varchar(32) CHARACTER SET utf8 COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `matkhau` varchar(32) CHARACTER SET utf8 COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `level` varchar(32) CHARACTER SET utf8 COLLATE utf8_vietnamese_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `anh_bang_chung`
--

CREATE TABLE `anh_bang_chung` (
  `id` int(11) NOT NULL,
  `code` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci DEFAULT NULL,
  `anh` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Đang đổ dữ liệu cho bảng `anh_bang_chung`
--

INSERT INTO `anh_bang_chung` (`id`, `code`, `anh`) VALUES
(41, 'scriptalertmscript', '/anh/BC_7531.png'),
(40, 'le-duc-hoang-phuc', '/anh/BC_3908.png'),
(39, 'trinh-ngoc-minh-dz', '/anh/BC_0264.png'),
(42, 'van-huy-vo', '/anh/BC_7159.png'),
(43, 'phan-thanh-an', '/anh/BC_0926.png'),
(44, 'le-van-nam', '/anh/BC_9324.png'),
(45, 'le-van-nam', '/anh/BC_9516.png'),
(46, 'le-van-nam', '/anh/BC_6437.png'),
(47, 'le-van-nam', '/anh/BC_2749.png'),
(48, 'le-van-nam', '/anh/BC_9260.png'),
(49, 'le-van-nam', '/anh/BC_9573.png'),
(50, 'le-van-nam', '/anh/BC_7438.png'),
(51, 'vu-duc-anh', '/anh/BC_2187.png'),
(52, 'vu-duc-anh', '/anh/BC_6984.png'),
(53, 'dang-van-du', '/anh/BC_6795.png'),
(54, 'dang-van-du', '/anh/BC_4153.png'),
(55, 'minh-duc', '/anh/BC_8124.png'),
(56, 'dang-dinh-dan', '/anh/BC_1870.png'),
(57, 'bay-bu', '/anh/BC_0386.png'),
(58, 'tong-nguyen-tien-anh', '/anh/BC_3218.png'),
(59, 'ha-gia-bao', '/anh/BC_3167.png'),
(60, 'ha-gia-bao', '/anh/BC_9825.png'),
(61, 'nguyen-chanh-tuan', '/anh/BC_4693.png'),
(62, 'nguyen-chanh-tuan', '/anh/BC_2579.png'),
(63, 'nguyen-chanh-tuan', '/anh/BC_3627.png'),
(64, 'nguyen-chanh-tuan', '/anh/BC_8942.png'),
(65, 'nguyen-chanh-tuan', '/anh/BC_7483.png'),
(66, 'nguyen-chanh-tuan', '/anh/BC_6397.png'),
(67, 'nguyen-manh-huyen', '/anh/BC_4386.png'),
(68, 'nguyen-manh-huyen', '/anh/BC_7198.png'),
(69, 'nguyen-manh-huyen', '/anh/BC_0146.png'),
(70, 'nguyen-manh-huyen', '/anh/BC_5173.png'),
(71, 'nguyen-manh-huyen', '/anh/BC_8504.png'),
(72, 'nguyen-manh-huyen', '/anh/BC_2046.png'),
(73, 'nguyen-manh-huyen', '/anh/BC_0178.png'),
(74, 'nguyen-manh-huyen', '/anh/BC_4170.png'),
(75, 'truong-tuan-anh', '/anh/BC_2908.png'),
(76, 'nguyen-manh-huyen', '/anh/BC_8514.png'),
(77, 'nguyen-manh-huyen', '/anh/BC_4571.png'),
(78, 'nguyen-manh-huyen', '/anh/BC_8571.png'),
(79, 'nguyen-manh-huyen', '/anh/BC_4013.png'),
(80, 'nguyen-manh-huyen', '/anh/BC_9486.png'),
(81, 'nguyen-manh-huyen', '/anh/BC_5724.png'),
(82, 'nguyen-manh-huyen', '/anh/BC_4061.png'),
(83, 'nguyen-manh-huyen', '/anh/BC_3862.png'),
(84, 'nguyen-manh-huyen', '/anh/BC_2107.png'),
(85, 'nguyen-manh-huyen', '/anh/BC_7856.png'),
(86, 'nguyen-manh-huyen', '/anh/BC_9537.png'),
(87, 'nguyen-manh-huyen', '/anh/BC_6034.png'),
(88, 'nguyen-manh-huyen', '/anh/BC_5417.png'),
(89, 'nguyen-manh-huyen', '/anh/BC_2419.png'),
(90, 'nguyen-manh-huyen', '/anh/BC_5938.png'),
(91, 'nguyen-manh-huyen', '/anh/BC_5127.png'),
(92, 'nguyen-manh-huyen', '/anh/BC_6430.png'),
(93, 'nguyen-manh-huyen', '/anh/BC_8017.png'),
(94, 'nguyen-manh-huyen', '/anh/BC_3604.png'),
(95, 'mai-thuan-thao', '/anh/BC_6714.png'),
(96, 'mai-thuan-thao', '/anh/BC_1620.png'),
(97, 'mai-thuan-thao', '/anh/BC_2935.png'),
(98, 'mai-thuan-thao', '/anh/BC_4093.png'),
(99, 'nguyen-manh-huyen', '/anh/BC_3962.png'),
(100, 'nguyen-manh-huyen', '/anh/BC_5847.png'),
(101, 'nguyen-manh-huyen', '/anh/BC_4596.png'),
(102, 'nguyen-manh-huyen', '/anh/BC_4120.png'),
(103, 'nguyen-manh-huyen', '/anh/BC_6790.png'),
(104, 'nguyen-manh-huyen', '/anh/BC_2849.png'),
(105, 'nguyen-manh-huyen', '/anh/BC_9240.png'),
(106, 'nguyen-manh-huyen', '/anh/BC_5237.png'),
(107, 'nguyen-manh-huyen', '/anh/BC_7954.png'),
(108, 'nguyen-manh-huyen', '/anh/BC_2357.png'),
(109, 'nguyen-manh-huyen', '/anh/BC_3408.png'),
(110, 'nguyen-manh-huyen', '/anh/BC_0947.png'),
(111, 'nguyen-manh-huyen', '/anh/BC_1362.png'),
(112, 'nguyen-manh-huyen', '/anh/BC_8523.png'),
(113, 'nguyen-manh-huyen', '/anh/BC_3510.png'),
(114, 'nguyen-manh-huyen', '/anh/BC_6027.png'),
(115, 'nguyen-manh-huyen', '/anh/BC_6798.png'),
(116, 'nguyen-manh-huyen', '/anh/BC_2014.png');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `bang`
--

CREATE TABLE `bang` (
  `id` int(11) NOT NULL,
  `code` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

--
-- Đang đổ dữ liệu cho bảng `bang`
--

INSERT INTO `bang` (`id`, `code`) VALUES
(88, 'ADMIN'),
(90, 'CTV'),
(91, 'Kiểm Duyệt Viên'),
(92, 'Thủ Quỹ');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `cards`
--

CREATE TABLE `cards` (
  `id` int(11) NOT NULL,
  `code` varchar(32) DEFAULT NULL,
  `username` text CHARACTER SET utf8mb4 NOT NULL,
  `sdt` text DEFAULT NULL,
  `id_fb` text CHARACTER SET utf8mb4 DEFAULT NULL,
  `website` text CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci NOT NULL,
  `dich_vu` text CHARACTER SET utf8mb4 DEFAULT NULL,
  `mo_ta` text CHARACTER SET utf8mb4 DEFAULT NULL,
  `money` text CHARACTER SET utf8mb4 DEFAULT NULL,
  `gmail` text CHARACTER SET utf8mb4 DEFAULT NULL,
  `ngan_hang` text CHARACTER SET utf8mb4 DEFAULT NULL,
  `vi_momo` text CHARACTER SET utf8mb4 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

--
-- Đang đổ dữ liệu cho bảng `cards`
--

INSERT INTO `cards` (`id`, `code`, `username`, `sdt`, `id_fb`, `website`, `dich_vu`, `mo_ta`, `money`, `gmail`, `ngan_hang`, `vi_momo`) VALUES
(161, 'pham-quang-nhat', 'Phạm Quang Nhật', '0375343460', '100046598650791', 'PQNIT.ASIA', 'QUỸ BẢO HIỂM MMO', '<p>dd</p>', '5000000', 'nhatcssit@gmail.com', 'Mb Bank: 6011112004', 'Momo: 0375343460');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `code` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

--
-- Đang đổ dữ liệu cho bảng `category`
--

INSERT INTO `category` (`id`, `code`) VALUES
(220, 'QUỸ BẢO HIỂM MMO'),
(223, 'DZ');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `ctv`
--

CREATE TABLE `ctv` (
  `id` int(11) NOT NULL,
  `code` varchar(32) CHARACTER SET utf8 COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `username` varchar(32) CHARACTER SET utf8 COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `email` text CHARACTER SET utf8 COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `password` text NOT NULL,
  `level` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

--
-- Đang đổ dữ liệu cho bảng `ctv`
--

INSERT INTO `ctv` (`id`, `code`, `username`, `email`, `password`, `level`) VALUES
(924, 'HACK', '', '', '', '1'),
(925, 'HACK', 'admin', '', 'phucok', '1'),
(926, 'HACK', '', '', '', '1'),
(927, 'HACK', 'Ahihingocminh', '', 'minhtn2007', '1'),
(928, 'HACK', 'admin', '', 'phucok', '1'),
(929, 'HACK', 'admin', '', 'phucoj', '1'),
(930, 'HACK', 'admin', '', 'phucoj', '1'),
(931, 'HACK', 'admin', '', 'phucoj', '1'),
(932, 'HACK', '', '', '', '1'),
(933, 'HACK', '', '', '', '1'),
(934, 'HACK', '', '', '', '1'),
(935, 'HACK', '', '', '', '1'),
(936, 'HACK', '', '', '', '1'),
(937, 'HACK', 'Ahihingocminh', '', 'minhtn2007', '1'),
(938, 'HACK', 'Ahihingocminh', '', 'minhtn2007', '1'),
(939, 'HACK', 'Ahihingocminh', '', 'minhtn2007', '1'),
(940, 'HACK', 'admin', '', 'phucok', '1'),
(941, 'HACK', 'admin', '', 'phucok', '1'),
(942, 'HACK', 'admin', '', 'phucok', '1'),
(943, 'HACK', 'admin', '', 'phucok', '1'),
(944, 'HACK', 'admin', '', 'phucok', '1'),
(945, 'HACK', 'admin', '', 'phucok', '1'),
(946, 'HACK', 'admin', '', 'phucok', '1'),
(947, 'HACK', 'admin', '', 'phucok', '1'),
(948, 'HACK', 'admin', '', 'phucok', '1'),
(949, 'HACK', 'admin', '', 'phucok', '1'),
(950, 'HACK', 'admin', '', 'phucok', '1'),
(951, 'HACK', 'Ahihingocminh', '', 'minhtn2007', '1'),
(952, 'HACK', 'Ahihingocminh', '', 'minhtn2007', '1'),
(953, 'HACK', 'Ahihingocminh', '', 'minhtn2007', '1'),
(954, 'HACK', 'Ahihingocminh', '', 'minhtn2007', '1'),
(955, 'HACK', 'Ahihingocminh', '', 'minhtn2007', '1'),
(956, 'HACK', 'Ahihingocminh', '', 'minhtn2007', '1'),
(957, 'HACK', 'admin', '', 'phucok', '1'),
(958, 'HACK', 'Ahihingocminh', '', 'minhtn2007', '1'),
(959, 'HACK', '', '', '', '1'),
(960, 'HACK', '', '', '', '1'),
(961, 'HACK', '', '', '', '1'),
(962, 'HACK', 'admin', '', 'phucok', '1'),
(963, 'HACK', 'admin', '', 'admin', '1'),
(964, 'HACK', 'admin', '', 'admin', '1'),
(965, 'HACK', 'doantrungnguyen', '', '2353177927', '1'),
(966, 'HACK', '', '', '', '1'),
(967, 'HACK', 'admin', '', 'phucok', '1'),
(968, 'HACK', 'admin', '', 'phucok', '1'),
(969, 'HACK', '', '', '', '1'),
(970, 'HACK', 'Ahihingocminh', '', 'minhtn2007', '1'),
(971, 'HACK', '', '', '', '1'),
(972, 'HACK', 'admin', '', 'phucok', '1'),
(973, 'HACK', '', '', '', '1'),
(974, 'HACK', '', '', '', '1'),
(975, 'HACK', 'admin', '', 'phucok', '1'),
(976, 'HACK', 'Ahihingocminh', '', 'minhtn2007', '1'),
(977, 'HACK', '', '', '', '1'),
(978, 'HACK', 'Ahihingocminh', '', 'minhtn2007', '1'),
(979, 'HACK', '', '', '', '1'),
(980, 'HACK', '', '', '', '1'),
(981, 'HACK', 'leduchoangphuc2504', '', 'phucok', '1'),
(982, 'HACK', 'leduchoangphuc2504', '', 'phucok', '1'),
(983, 'HACK', 'Ahihingocminh', '', 'minhtn2007', '1'),
(984, 'HACK', '', '', '', '1'),
(985, 'HACK', 'Ahihingocminh', '', 'minhtn2007', '1'),
(986, 'HACK', 'Ahihingocminh', '', 'minhtn2007', '1'),
(987, 'HACK', 'Ahihingocminh', '', 'minhtn2007', '1'),
(988, 'HACK', 'admin', '', 'ccc', '1'),
(989, 'HACK', '', '', '', '1'),
(990, 'HACK', 'admin', '', 'minh', '1'),
(991, 'HACK', 'admin', '', 'minh', '1'),
(992, 'HACK', '', '', '', '1'),
(993, 'HACK', '', '', '', '1'),
(994, 'HACK', 'admin', '', 'minh', '1'),
(995, 'HACK', '', '', '', '1'),
(996, 'HACK', 'admin@', '', 'admin@lequyphu', '1'),
(997, 'HACK', 'admin@', '', 'admin@lequyphu', '1'),
(998, 'HACK', 'admin', '', 'vinh', '1'),
(999, 'HACK', 'admin', '', 'admin123@', '1'),
(1000, 'HACK', '', '', '', '1'),
(1001, 'HACK', '', '', '', '1'),
(1002, 'HACK', '', '', '', '1'),
(1003, 'HACK', '', '', '', '1'),
(1004, 'HACK', '', '', '', '1'),
(1005, 'HACK', '', '', '', '1'),
(1006, 'HACK', '', '', '', '1'),
(1007, 'HACK', '', '', '', '1'),
(1008, 'HACK', '', '', '', '1'),
(1009, 'HACK', '', '', '', '1'),
(1010, 'HACK', 'admin@', '', 'admin@123', '1'),
(1011, 'HACK', 'admin@', '', 'admin@123', '1'),
(1012, 'HACK', 'admin', '', 'admin@123', '1'),
(1013, 'HACK', 'admin', '', 'admin123@', '1'),
(1014, 'HACK', '', '', '', '1'),
(1015, 'HACK', '', '', '', '1'),
(1016, 'HACK', '', '', '', '1'),
(1017, 'HACK', '', '', '', '1'),
(1018, 'HACK', '', '', '', '1'),
(1019, 'HACK', '', '', '', '1'),
(1020, 'HACK', 'admin', '', 'admin123@', '1'),
(1021, 'HACK', '', '', '', '1'),
(1022, 'HACK', 'admin', '', 'admin123@', '1'),
(1023, 'HACK', '', '', '', '1'),
(1024, 'HACK', '', '', '', '1'),
(1025, 'HACK', '', '', '', '1'),
(1026, 'HACK', 'admin', '', 'admin@123', '1'),
(1027, 'HACK', 'admin', '', 'admin123@', '1'),
(1028, 'HACK', '', '', '', '1'),
(1029, 'HACK', '', '', '', '1'),
(1030, 'HACK', '', '', '', '1'),
(1031, 'HACK', '', '', '', '1'),
(1032, 'HACK', '', '', '', '1'),
(1033, 'HACK', '', '', '', '1'),
(1034, 'HACK', 'admin', '', 'admin123@', '1'),
(1035, 'HACK', '', '', '', '1'),
(1036, 'HACK', '', '', '', '1'),
(1037, 'HACK', '', '', '', '1'),
(1038, 'HACK', '', '', '', '1'),
(1039, 'HACK', '', '', '', '1'),
(1040, 'HACK', '', '', '', '1'),
(1041, 'HACK', 'admin', '', 'admin123@', '1'),
(1042, 'HACK', '', '', '', '1'),
(1043, 'HACK', '', '', '', '1'),
(1044, 'HACK', '', '', '', '1'),
(1045, 'HACK', '', '', '', '1'),
(1046, 'HACK', '', '', '', '1'),
(1047, 'HACK', '', '', '', '1'),
(1048, 'HACK', '', '', '', '1'),
(1049, 'HACK', '', '', '', '1'),
(1050, 'HACK', '', '', '', '1'),
(1051, 'HACK', '', '', '', '1'),
(1052, 'HACK', '', '', '', '1'),
(1053, 'HACK', '', '', '', '1'),
(1054, 'HACK', 'admin', '', 'admin123@', '1'),
(1055, 'HACK', '', '', '', '1'),
(1056, 'HACK', '', '', '', '1'),
(1057, 'HACK', '', '', '', '1'),
(1058, 'HACK', '1@', '', '1@', '1'),
(1059, 'HACK', '1@', '', '1@', '1'),
(1060, 'HACK', 'admin', '', 'admin123@', '1'),
(1061, 'HACK', 'admin', '', 'admin123@@', '1'),
(1062, 'HACK', 'admin', '', 'admin123@', '1'),
(1063, 'HACK', '', '', '', '1'),
(1064, 'HACK', '', '', '', '1'),
(1065, 'HACK', '', '', '', '1'),
(1066, 'HACK', '', '', '', '1'),
(1067, 'HACK', '', '', '', '1'),
(1068, 'HACK', '', '', '', '1'),
(1069, 'HACK', '', '', '', '1'),
(1070, 'HACK', '', '', '', '1'),
(1071, 'HACK', '', '', '', '1'),
(1072, 'HACK', '', '', '', '1'),
(1073, 'HACK', '', '', '', '1'),
(1074, 'HACK', '', '', '', '1'),
(1075, 'HACK', '', '', '', '1'),
(1076, 'HACK', '', '', '', '1'),
(1077, 'HACK', '', '', '', '1'),
(1078, 'HACK', '', '', '', '1'),
(1079, 'HACK', '', '', '', '1'),
(1080, 'HACK', '', '', '', '1'),
(1081, 'HACK', '', '', '', '1'),
(1082, 'HACK', 'admin', '', 'admin123@', '1'),
(1083, 'HACK', '', '', '', '1'),
(1084, 'HACK', 'admin', '', 'admin123@', '1'),
(1085, 'HACK', '', '', '', '1'),
(1086, 'HACK', '', '', '', '1'),
(1087, 'HACK', '', '', '', '1'),
(1088, 'HACK', '', '', '', '1'),
(1089, 'HACK', '', '', '', '1'),
(1090, 'HACK', 'admin', '', 'admin@', '1'),
(1091, 'HACK', 'admin', '', 'admin123@', '1'),
(1092, 'HACK', 'admin', '', 'admin123@', '1'),
(1093, 'HACK', '', '', '', '1'),
(1094, 'HACK', '1@', '', '1@', '1'),
(1095, 'HACK', '1@', '', '1@', '1'),
(1096, 'HACK', '', '', '', '1'),
(1097, 'HACK', '', '', '', '1'),
(1098, 'HACK', '', '', '', '1'),
(1099, 'HACK', '', '', '', '1'),
(1100, 'HACK', '', '', '', '1'),
(1101, 'HACK', '', '', '', '1'),
(1102, 'HACK', '', '', '', '1'),
(1103, 'HACK', '', '', '', '1'),
(1104, 'HACK', '', '', '', '1'),
(1105, 'HACK', '', '', '', '1'),
(1106, 'HACK', '', '', '', '1'),
(1107, 'HACK', '', '', '', '1'),
(1108, 'HACK', '', '', '', '1'),
(1109, 'HACK', '', '', '', '1'),
(1110, 'HACK', '', '', '', '1'),
(1111, 'HACK', '', '', '', '1'),
(1112, 'HACK', '', '', '', '1'),
(1113, 'HACK', '', '', '', '1'),
(1114, 'HACK', '', '', '', '1'),
(1115, 'HACK', '1@', '', '1@', '1'),
(1116, 'HACK', '', '', '', '1'),
(1117, 'HACK', '', '', '', '1'),
(1118, 'HACK', '1@', '', '1@', '1'),
(1119, 'HACK', '1@', '', '1@', '1'),
(1120, 'HACK', '', '', '', '1'),
(1121, 'HACK', '1@', '', '1@', '1'),
(1122, 'HACK', '1@', '', '1@', '1'),
(1123, 'HACK', '', '', '', '1'),
(1124, 'HACK', '', '', '', '1'),
(1125, 'HACK', '', '', '', '1'),
(1126, 'HACK', '1@', '', '1@', '1'),
(1127, 'HACK', '', '', '', '1'),
(1128, 'HACK', '1@', '', '1@', '1'),
(1129, 'HACK', '1@', '', '1@', '1'),
(1130, 'HACK', '', '', '', '1'),
(1131, 'HACK', '', '', '', '1'),
(1132, 'HACK', '', '', '', '1'),
(1133, 'HACK', '', '', '', '1'),
(1134, 'HACK', '', '', '', '1'),
(1135, 'HACK', '', '', '', '1'),
(1136, 'HACK', '1@', '', '1@', '1'),
(1137, 'HACK', '1@', '', '1@', '1'),
(1138, 'HACK', '', '', '', '1'),
(1139, 'HACK', '', '', '', '1'),
(1140, 'HACK', '1@', '', '1@', '1'),
(1141, 'HACK', '', '', '', '1'),
(1142, 'HACK', 'admin', '', 'admin', '1'),
(1143, 'HACK', '', '', '', '1'),
(1144, 'HACK', '1@', '', '1@', '1'),
(1145, 'HACK', '', '', '', '1'),
(1146, 'HACK', '', '', '', '1'),
(1147, 'HACK', '', '', '', '1'),
(1148, 'HACK', '', '', '', '1'),
(1149, 'HACK', '', '', '', '1'),
(1150, 'HACK', '', '', '', '1'),
(1151, 'HACK', '', '', '', '1'),
(1152, 'HACK', '', '', '', '1'),
(1153, 'HACK', '', '', '', '1'),
(1154, 'HACK', '', '', '', '1'),
(1155, 'HACK', '', '', '', '1'),
(1156, 'HACK', '', '', '', '1'),
(1157, 'HACK', '', '', '', '1'),
(1158, 'HACK', '', '', '', '1'),
(1159, 'HACK', '', '', '', '1'),
(1160, 'HACK', '', '', '', '1'),
(1161, 'HACK', '', '', '', '1'),
(1162, 'HACK', '', '', '', '1'),
(1163, 'HACK', '', '', '', '1'),
(1164, 'HACK', '', '', '', '1'),
(1165, 'HACK', '', '', '', '1'),
(1166, 'HACK', '', '', '', '1'),
(1167, 'HACK', '', '', '', '1'),
(1168, 'HACK', '', '', '', '1'),
(1169, 'HACK', '', '', '', '1'),
(1170, 'HACK', '', '', '', '1'),
(1171, 'HACK', '', '', '', '1'),
(1172, 'HACK', '', '', '', '1'),
(1173, 'HACK', '', '', '', '1'),
(1174, 'HACK', '1@', '', '1@', '1'),
(1175, 'HACK', '', '', '', '1'),
(1176, 'HACK', '', '', '', '1'),
(1177, 'HACK', '1@', '', '1@', '1'),
(1178, 'HACK', '', '', '', '1'),
(1179, 'HACK', '', '', '', '1'),
(1180, 'HACK', '', '', '', '1'),
(1181, 'HACK', '', '', '', '1'),
(1182, 'HACK', '1@', '', '1@', '1'),
(1183, 'HACK', '', '', '', '1'),
(1184, 'HACK', '', '', '', '1'),
(1185, 'HACK', '', '', '', '1'),
(1186, 'HACK', '', '', '', '1'),
(1187, 'HACK', '1@', '', '1@', '1'),
(1188, 'HACK', '', '', '', '1'),
(1189, 'HACK', '', '', '', '1'),
(1190, 'HACK', '1@', '', '1@', '1'),
(1191, 'HACK', '', '', '', '1'),
(1192, 'HACK', '1@', '', '1@', '1'),
(1193, 'HACK', '1@', '', '1@', '1'),
(1194, 'HACK', '', '', '', '1'),
(1195, 'HACK', '1@', '', '1@', '1'),
(1196, 'HACK', '', '', '', '1'),
(1197, 'HACK', '', '', '', '1'),
(1198, 'HACK', '', '', '', '1'),
(1199, 'HACK', '1@', '', '1@', '1'),
(1200, 'HACK', '', '', '', '1'),
(1201, 'HACK', '', '', '', '1'),
(1202, 'HACK', '', '', '', '1'),
(1203, 'HACK', '1@', '', '1@', '1'),
(1204, 'HACK', '', '', '', '1'),
(1205, 'HACK', 'Hoangmaithuan', '', 'thuan123', '1'),
(1206, 'HACK', '', '', '', '1'),
(1207, 'HACK', '1@', '', '1@', '1'),
(1208, 'HACK', '', '', '', '1'),
(1209, 'HACK', '1@', '', '1@', '1'),
(1210, 'HACK', '1@', '', '1@', '1'),
(1211, 'HACK', '', '', '', '1'),
(1212, 'HACK', '', '', '', '1'),
(1213, 'HACK', '1@', '', '1@', '1'),
(1214, 'HACK', '', '', '', '1'),
(1215, 'HACK', '', '', '', '1'),
(1216, 'HACK', '1@', '', '1@', '1'),
(1217, 'HACK', '', '', '', '1'),
(1218, 'HACK', '1@', '', '1@', '1'),
(1219, 'HACK', '', '', '', '1'),
(1220, 'HACK', '1@', '', '1#', '1'),
(1221, 'HACK', '1@', '', '1@', '1'),
(1222, 'HACK', '', '', '', '1'),
(1223, 'HACK', '', '', '', '1'),
(1224, 'HACK', 'hoangmaithuan', '', 'nguyenvietduc', '1'),
(1225, 'HACK', '1@', '', '1@', '1'),
(1226, 'HACK', '', '', '', '1'),
(1227, 'HACK', '', '', '', '1'),
(1228, 'HACK', '1@', '', '1@', '1'),
(1229, 'HACK', '1@', '', '1@', '1'),
(1230, 'HACK', '', '', '', '1'),
(1231, 'HACK', '1@', '', '1@', '1'),
(1232, 'HACK', '1@', '', '1@', '1'),
(1233, 'HACK', '', '', '', '1'),
(1234, 'HACK', '', '', '', '1'),
(1235, 'HACK', '', '', '', '1'),
(1236, 'HACK', '', '', '', '1'),
(1237, 'HACK', '', '', '', '1'),
(1238, 'HACK', '1@', '', '1@', '1'),
(1239, 'HACK', '1@', '', '1@', '1'),
(1240, 'HACK', '', '', '', '1'),
(1241, 'HACK', '1@', '', '1@', '1'),
(1242, 'HACK', '', '', '', '1'),
(1243, 'HACK', '', '', '', '1'),
(1244, 'HACK', '1@', '', '1@', '1'),
(1245, 'HACK', '1@', '', '1@', '1'),
(1246, 'HACK', '', '', '', '1'),
(1247, 'HACK', '1@', '', '1@', '1'),
(1248, 'HACK', '', '', '', '1'),
(1249, 'HACK', '', '', '', '1'),
(1250, 'HACK', '1@', '', '1@', '1'),
(1251, 'HACK', '1@', '', '1@', '1'),
(1252, 'HACK', '1@', '', '1@', '1'),
(1253, 'HACK', '1@', '', '1@', '1'),
(1254, 'HACK', '', '', '', '1'),
(1255, 'HACK', '', '', '', '1'),
(1256, 'HACK', '1@', '', '1@', '1'),
(1257, 'HACK', '1@', '', '123', '1'),
(1258, 'HACK', '1@', '', '123', '1'),
(1259, 'HACK', '1@', '', '123', '1'),
(1260, 'HACK', '1@', '', '123', '1'),
(1261, 'HACK', '1@', '', '123', '1'),
(1262, 'HACK', '', '', '', '1'),
(1263, 'HACK', '', '', '', '1'),
(1264, 'HACK', '1@', '', '123', '1'),
(1265, 'HACK', '1@', '', '123', '1'),
(1266, 'HACK', '1@', '', '123', '1'),
(1267, 'HACK', '1@', '', '123', '1'),
(1268, 'HACK', '', '', '', '1'),
(1269, 'HACK', '', '', '', '1'),
(1270, 'HACK', '', '', '', '1'),
(1271, 'HACK', 'nguyenmanhhuyendz', '', 'nguyenmanhhuyendz', '1'),
(1272, 'HACK', '', '', '', '1'),
(1273, 'HACK', 'nguyenmanhhuyendz', '', 'nguyenmanhhuyendz', '1'),
(1274, 'HACK', '', '', '', '1'),
(1275, 'HACK', '', '', '', '1'),
(1276, 'HACK', '', '', '', '1'),
(1277, 'HACK', '', '', '', '1'),
(1278, 'HACK', '', '', '', '1'),
(1279, 'HACK', '', '', '', '1'),
(1280, 'HACK', '', '', '', '1'),
(1281, 'HACK', '', '', '', '1'),
(1282, 'HACK', '1@', '', '123', '1'),
(1283, 'HACK', 'nguyenmanhhuyendz', '', 'nguyenmanhhuyendz', '1'),
(1284, 'HACK', '', '', '', '1'),
(1285, 'HACK', 'nguyenmanhhuyendz', '', 'nguyenmanhhuyendz', '1'),
(1286, 'HACK', '', '', '', '1'),
(1287, 'HACK', '', '', '', '1'),
(1288, 'HACK', '', '', '', '1'),
(1289, 'HACK', '', '', '', '1'),
(1290, 'HACK', '', '', '', '1'),
(1291, 'HACK', '', '', '', '1'),
(1292, 'HACK', '', '', '', '1'),
(1293, 'HACK', '', '', '', '1'),
(1294, 'HACK', '', '', '', '1'),
(1295, 'HACK', '', '', '', '1'),
(1296, 'HACK', '', '', '', '1'),
(1297, 'HACK', '', '', '', '1'),
(1298, 'HACK', '', '', '', '1'),
(1299, 'HACK', '', '', '', '1'),
(1300, 'HACK', '', '', '', '1'),
(1301, 'HACK', '', '', '', '1'),
(1302, 'HACK', '', '', '', '1'),
(1303, 'HACK', '', '', '', '1'),
(1304, 'HACK', '', '', '', '1'),
(1305, 'HACK', '', '', '', '1'),
(1306, 'HACK', '', '', '', '1'),
(1307, 'HACK', '', '', '', '1'),
(1308, 'HACK', 'manhhuyen01', '', 'manhhuyen02', '1'),
(1309, 'HACK', 'vuducanh2006dz', '', 'vuducanh2006dz', '1'),
(1310, 'HACK', 'nguyenmanhhuyendz', '', 'nguyenmanhhuyendz', '1'),
(1311, 'HACK', '', '', '', '1'),
(1312, 'HACK', '', '', '', '1'),
(1313, 'HACK', '', '', '', '1'),
(1314, 'HACK', '', '', '', '1'),
(1315, 'HACK', 'nguyenmanhhuyendz', '', 'nguyenmanhhuyendz', '1'),
(1316, 'HACK', '', '', '', '1'),
(1317, 'HACK', '', '', '', '1'),
(1318, 'HACK', 'nguyenmanhhuyendz', '', 'nguyenmanhhuyendz', '1'),
(1319, 'HACK', '', '', '', '1'),
(1320, 'HACK', 'nguyenmanhhuyendz', '', 'nguyenmanhhuyendz', '1'),
(1321, 'HACK', 'nguyenmanhhuyendz', '', 'nguyenmanhhuyendz', '1'),
(1322, 'HACK', '', '', '', '1'),
(1323, 'HACK', '', '', '', '1'),
(1324, 'HACK', 'nguyenmanhhuyendz', '', 'nguyenmanhhuyendz', '1'),
(1325, 'HACK', '', '', '', '1'),
(1326, 'HACK', '', '', '', '1'),
(1327, 'HACK', 'nguyenmanhhuyendz', '', 'nguyenmanhhuyendz', '1'),
(1328, 'HACK', '', '', '', '1'),
(1329, 'HACK', '', '', '', '1'),
(1330, 'HACK', '', '', '', '1'),
(1331, 'HACK', '', '', '', '1'),
(1332, 'HACK', '', '', '', '1'),
(1333, 'HACK', '', '', '', '1'),
(1334, 'HACK', 'nguyenmanhhuyendz', '', 'nguyenmanhhuyendz', '1'),
(1335, 'HACK', '', '', '', '1'),
(1336, 'HACK', '', '', '', '1'),
(1337, 'HACK', '', '', '', '1'),
(1338, 'HACK', '', '', '', '1'),
(1339, 'HACK', '', '', '', '1'),
(1340, 'HACK', '', '', '', '1'),
(1341, 'HACK', '', '', '', '1'),
(1342, 'HACK', '', '', '', '1'),
(1343, 'HACK', '', '', '', '1'),
(1344, 'HACK', 'nguyenmanhhuyendz', '', 'nguyenmanhhuyendz', '1'),
(1345, 'HACK', '', '', '', '1'),
(1346, 'HACK', '', '', '', '1'),
(1347, 'HACK', '', '', '', '1'),
(1348, 'HACK', 'admin', '', '1', '1'),
(1349, 'HACK', 'admin', '', 'admin123@', '1'),
(1350, 'HACK', 'leduchoangphuc2504', '', 'phucdz', '1'),
(1351, 'HACK', 'nguyenmanhhuyendz', '', 'nguyenmanhhuyendz', '1'),
(1352, 'HACK', '', '', '', '1'),
(1353, 'HACK', 'admin', '', 'pqnitdzvcl', '1'),
(1354, 'HACK', '', '', '', '1'),
(1355, 'HACK', '', '', '', '1'),
(1356, 'HACK', '', '', '', '1'),
(1357, 'HACK', '', '', '', '1'),
(1358, 'HACK', '', '', '', '1'),
(1359, 'HACK', '', '', '', '1'),
(1360, 'HACK', '', '', '', '1'),
(1361, 'HACK', '', '', '', '1');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `lang`
--

CREATE TABLE `lang` (
  `id` int(11) NOT NULL,
  `msg1` text COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `msg2` text COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `msg3` text COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `msg4` text COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `msg5` text COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `msg6` text COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `msg7` text COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `msg8` text COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `msg9` text COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `msg10` text COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `msg11` text COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `msg12` text COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `msg13` text COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `14` text COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `15` text COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `16` text COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `17` text COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `18` text COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `19` text COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `20` text COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `side1` text COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `side2` text COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `side3` text COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `side4` text COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `side5` text COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `side6` text COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `side7` text COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `side8` text COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `side9` text COLLATE utf8_vietnamese_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci ROW_FORMAT=DYNAMIC;

--
-- Đang đổ dữ liệu cho bảng `lang`
--

INSERT INTO `lang` (`id`, `msg1`, `msg2`, `msg3`, `msg4`, `msg5`, `msg6`, `msg7`, `msg8`, `msg9`, `msg10`, `msg11`, `msg12`, `msg13`, `14`, `15`, `16`, `17`, `18`, `19`, `20`, `side1`, `side2`, `side3`, `side4`, `side5`, `side6`, `side7`, `side8`, `side9`) VALUES
(1, 'Vui lòng điền vào ô trống !', 'Tài khoản không tồn tại trong hệ thống !', 'Địa chỉ Email đã tồn tại !', 'IP này đã đạt giới hạn tạo tài khoản!', 'Đăng ký tài khoản thành công !', 'Vui lòng điền vào ô trống !', 'Tài khoản không tồn tại trong hệ thống !', 'Mật khẩu không chính xác', 'Đăng nhập thành công !', 'Vui lòng điền vào ô trống !', 'Địa chỉ email không hợp lệ !', 'Địa chỉ email không có trong hệ thống !', 'Vui lòng kiểm tra hòm thư Email của bạn!', 'Vui lòng đăng nhập để tiếp tục', 'Số lượng tối thiểu là 1 tài khoản !', 'Số lượng tối đa khi mua 1 lần là 10.000 !', 'Loại tài khoản không tồn tại !', 'Số tài khoản trong hệ thống không đủ !', 'Số dư không đủ thanh toán!', 'Số lượng tài khoản không đủ, vui lòng thử lại', 'Home', 'Mua Tài Khoản', 'Nạp Tiền', 'Lịch Sử Đơn Hàng', 'Công Cụ', 'Giftcode', 'Cộng Tác Viên', 'Yêu Cầu Hỗ Trợ', 'Liên Hệ Facebook');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `setting`
--

CREATE TABLE `setting` (
  `id` int(11) NOT NULL,
  `site_image` text DEFAULT NULL,
  `site_domain` text DEFAULT NULL,
  `site_favicon` text DEFAULT NULL,
  `site_logo` text DEFAULT NULL,
  `site_tenweb` text DEFAULT NULL,
  `site_mota` text DEFAULT NULL,
  `facebook` text CHARACTER SET utf8 COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `sdt_admin` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;

--
-- Đang đổ dữ liệu cho bảng `setting`
--

INSERT INTO `setting` (`id`, `site_image`, `site_domain`, `site_favicon`, `site_logo`, `site_tenweb`, `site_mota`, `facebook`, `sdt_admin`) VALUES
(1, '/img/cover.png', 'http://kiemtrascam24h.info/', '/upload/favicon_3521.png', 'https://i.imgur.com/7qwJFeq.png', 'kiemtrascam24h.info', 'kiemtrascam24h.info | nơi tố các những kẻ lừa đảo đang lộng hành trên mạng xã hội', '', '0333611627');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `ticket`
--

CREATE TABLE `ticket` (
  `id` int(11) NOT NULL,
  `code` varchar(100) DEFAULT NULL,
  `username` text NOT NULL,
  `ly_do` text DEFAULT NULL,
  `status` varchar(32) NOT NULL,
  `sdt` text DEFAULT NULL,
  `ngan_hang` text DEFAULT NULL,
  `stk` text DEFAULT NULL,
  `anh` varchar(100) DEFAULT NULL,
  `bangchung` text DEFAULT NULL,
  `hoten_np` text DEFAULT NULL,
  `sdt_np` text DEFAULT NULL,
  `id_fb` text DEFAULT NULL,
  `ngay` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;

--
-- Đang đổ dữ liệu cho bảng `ticket`
--

INSERT INTO `ticket` (`id`, `code`, `username`, `ly_do`, `status`, `sdt`, `ngan_hang`, `stk`, `anh`, `bangchung`, `hoten_np`, `sdt_np`, `id_fb`, `ngay`) VALUES
(9, 'vuong-van-manh', ' Vương Văn Mạnh', 'DUY DZ', 'scam', '0972024512', 'MBBANK ', '8886306072007', 'vuong-van-manh', NULL, ' Trần Văn Linh', '0333', '100021392402690', '17-05-2022'),
(10, '', '', '', 'xuly', '', '', '', '', NULL, '', '', '', '17-05-2022');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tmanh`
--

CREATE TABLE `tmanh` (
  `id` int(11) NOT NULL,
  `code` varchar(9999) CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci DEFAULT NULL,
  `anh` text CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci DEFAULT NULL,
  `title` text CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci DEFAULT NULL,
  `note` text CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci DEFAULT NULL,
  `status` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci DEFAULT NULL,
  `time` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `code` varchar(32) CHARACTER SET utf8 COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `username` varchar(32) CHARACTER SET utf8 COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `password` varchar(32) CHARACTER SET utf8 COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `level` varchar(32) CHARACTER SET utf8 COLLATE utf8_vietnamese_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

--
-- Đang đổ dữ liệu cho bảng `users`
--

INSERT INTO `users` (`id`, `code`, `username`, `password`, `level`) VALUES
(1, 'ABCXYZ', 'admin', 'pqnitdzvcl', '1'),
(2, 'ABCXYZ', 'admin', 'teampqnit', '1');

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `abc`
--
ALTER TABLE `abc`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Chỉ mục cho bảng `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Chỉ mục cho bảng `anh_bang_chung`
--
ALTER TABLE `anh_bang_chung`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `bang`
--
ALTER TABLE `bang`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Chỉ mục cho bảng `cards`
--
ALTER TABLE `cards`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Chỉ mục cho bảng `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Chỉ mục cho bảng `ctv`
--
ALTER TABLE `ctv`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Chỉ mục cho bảng `lang`
--
ALTER TABLE `lang`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Chỉ mục cho bảng `setting`
--
ALTER TABLE `setting`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Chỉ mục cho bảng `ticket`
--
ALTER TABLE `ticket`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `tmanh`
--
ALTER TABLE `tmanh`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `abc`
--
ALTER TABLE `abc`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT cho bảng `anh_bang_chung`
--
ALTER TABLE `anh_bang_chung`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=117;

--
-- AUTO_INCREMENT cho bảng `bang`
--
ALTER TABLE `bang`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=93;

--
-- AUTO_INCREMENT cho bảng `cards`
--
ALTER TABLE `cards`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=162;

--
-- AUTO_INCREMENT cho bảng `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=224;

--
-- AUTO_INCREMENT cho bảng `ctv`
--
ALTER TABLE `ctv`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1362;

--
-- AUTO_INCREMENT cho bảng `lang`
--
ALTER TABLE `lang`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT cho bảng `setting`
--
ALTER TABLE `setting`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT cho bảng `ticket`
--
ALTER TABLE `ticket`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT cho bảng `tmanh`
--
ALTER TABLE `tmanh`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT cho bảng `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
